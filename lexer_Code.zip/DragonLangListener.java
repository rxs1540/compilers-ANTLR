// Generated from DragonLang.g4 by ANTLR 4.7.2

    import java.util.*;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DragonLangParser}.
 */
public interface DragonLangListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DragonLangParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DragonLangParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(DragonLangParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(DragonLangParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#decls}.
	 * @param ctx the parse tree
	 */
	void enterDecls(DragonLangParser.DeclsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#decls}.
	 * @param ctx the parse tree
	 */
	void exitDecls(DragonLangParser.DeclsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#decl}.
	 * @param ctx the parse tree
	 */
	void enterDecl(DragonLangParser.DeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#decl}.
	 * @param ctx the parse tree
	 */
	void exitDecl(DragonLangParser.DeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(DragonLangParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(DragonLangParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#basic}.
	 * @param ctx the parse tree
	 */
	void enterBasic(DragonLangParser.BasicContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#basic}.
	 * @param ctx the parse tree
	 */
	void exitBasic(DragonLangParser.BasicContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#stmts}.
	 * @param ctx the parse tree
	 */
	void enterStmts(DragonLangParser.StmtsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#stmts}.
	 * @param ctx the parse tree
	 */
	void exitStmts(DragonLangParser.StmtsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(DragonLangParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(DragonLangParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#loc}.
	 * @param ctx the parse tree
	 */
	void enterLoc(DragonLangParser.LocContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#loc}.
	 * @param ctx the parse tree
	 */
	void exitLoc(DragonLangParser.LocContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#bool}.
	 * @param ctx the parse tree
	 */
	void enterBool(DragonLangParser.BoolContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#bool}.
	 * @param ctx the parse tree
	 */
	void exitBool(DragonLangParser.BoolContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#join}.
	 * @param ctx the parse tree
	 */
	void enterJoin(DragonLangParser.JoinContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#join}.
	 * @param ctx the parse tree
	 */
	void exitJoin(DragonLangParser.JoinContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#equality}.
	 * @param ctx the parse tree
	 */
	void enterEquality(DragonLangParser.EqualityContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#equality}.
	 * @param ctx the parse tree
	 */
	void exitEquality(DragonLangParser.EqualityContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#rel}.
	 * @param ctx the parse tree
	 */
	void enterRel(DragonLangParser.RelContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#rel}.
	 * @param ctx the parse tree
	 */
	void exitRel(DragonLangParser.RelContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(DragonLangParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(DragonLangParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#term}.
	 * @param ctx the parse tree
	 */
	void enterTerm(DragonLangParser.TermContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#term}.
	 * @param ctx the parse tree
	 */
	void exitTerm(DragonLangParser.TermContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#unary}.
	 * @param ctx the parse tree
	 */
	void enterUnary(DragonLangParser.UnaryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#unary}.
	 * @param ctx the parse tree
	 */
	void exitUnary(DragonLangParser.UnaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DragonLangParser#factor}.
	 * @param ctx the parse tree
	 */
	void enterFactor(DragonLangParser.FactorContext ctx);
	/**
	 * Exit a parse tree produced by {@link DragonLangParser#factor}.
	 * @param ctx the parse tree
	 */
	void exitFactor(DragonLangParser.FactorContext ctx);
}